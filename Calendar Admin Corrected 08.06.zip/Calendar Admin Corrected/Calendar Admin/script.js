// Toggle dropdown functionality
function toggleDropdown(id) {
  const dropdown = document.getElementById(`${id}-dropdown`);
  const icon = document.getElementById(`${id}-icon`);
  
  // If dropdown doesn't exist, no need to proceed
  if (!dropdown) return;
  
  // Toggle the active class
  dropdown.classList.toggle('active');
  
  // Rotate the chevron icon
  if (dropdown.classList.contains('active')) {
    icon.classList.add('rotate-180');
  } else {
    icon.classList.remove('rotate-180');
  }
}

// Handle select all functionality for each section
function initializeSelectAll(sectionId) {
  const selectAllCheckbox = document.getElementById(`${sectionId}-select-all`);
  const rowCheckboxes = document.querySelectorAll(`.${sectionId}-row-checkbox`);
  
  if (selectAllCheckbox) {
    selectAllCheckbox.addEventListener('change', function() {
      const isChecked = this.checked;
      rowCheckboxes.forEach(checkbox => {
        checkbox.checked = isChecked;
      });
    });
    
    // Update select all when individual checkboxes change
    rowCheckboxes.forEach(checkbox => {
      checkbox.addEventListener('change', function() {
        const allChecked = [...rowCheckboxes].every(cb => cb.checked);
        selectAllCheckbox.checked = allChecked;
      });
    });
  }
}

// Handle action menu toggles
function initializeActionMenus() {
  const actionToggles = document.querySelectorAll('.action-toggle');
  let activeMenu = null;

  // Close menu when clicking outside
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.action-button-container')) {
      if (activeMenu) {
        activeMenu.classList.remove('active');
        activeMenu = null;
      }
    }
  });

  actionToggles.forEach(toggle => {
    toggle.addEventListener('click', (e) => {
      e.stopPropagation();
      const menu = toggle.nextElementSibling;
      
      // Close previously open menu
      if (activeMenu && activeMenu !== menu) {
        activeMenu.classList.remove('active');
      }
      
      // Toggle current menu
      menu.classList.toggle('active');
      activeMenu = menu.classList.contains('active') ? menu : null;
    });
  });

  // Handle action button clicks
  const actionButtons = document.querySelectorAll('.action-button');
  actionButtons.forEach(button => {
    button.addEventListener('click', (e) => {
      e.stopPropagation();
      const action = e.target.textContent;
      const row = e.target.closest('tr');
      
      switch(action) {
        case 'Add':
          window.location.href = '/1stpage.html';
          break;
        case 'Edit':
          window.location.href = '/1stpage.html';
          break;
        case 'Delete':
          if (confirm('Are you sure you want to delete this item?')) {
            row.remove();
          }
          break;
      }

      // Close the menu after action
      if (activeMenu) {
        activeMenu.classList.remove('active');
        activeMenu = null;
      }
    });
  });
}

// Initialize all sections
document.addEventListener('DOMContentLoaded', function() {
  const sections = ['holidays', 'birthday', 'example1', 'example2'];
  
  sections.forEach(section => {
    initializeSelectAll(section);
  });
  
  // Initialize action menus
  initializeActionMenus();
  
  // Prevent checkbox clicks from triggering the dropdown
  const checkboxes = document.querySelectorAll('.checkbox-custom');
  checkboxes.forEach(checkbox => {
    checkbox.addEventListener('click', function(event) {
      event.stopPropagation();
    });
  });
  
  // Make tables responsive
  const tables = document.querySelectorAll('table');
  tables.forEach(table => {
    const wrapper = document.createElement('div');
    wrapper.classList.add('overflow-x-auto');
    table.parentNode.insertBefore(wrapper, table);
    wrapper.appendChild(table);
  });
});


        // Global variables
        let events = [];
        let currentSort = { field: 'date', direction: 'asc' };
        let currentTimezone = '+05:30 India Standard Time';
        let currentDateFormat = 'MM/DD/YYYY';
        let timeFormat = '12H';

        // DOM Elements
        const newEventBtn = document.getElementById('newEventBtn');
        const newEventModal = document.getElementById('newEventModal');
        const closeModal = document.getElementById('closeModal');
        const cancelBtn = document.getElementById('cancelBtn');
        const saveEventBtn = document.getElementById('saveEventBtn');
        const eventForm = document.getElementById('eventForm');
        const tableBody = document.getElementById('tableBody');
        const filterInput = document.getElementById('filterInput');
        const scrollIndicator = document.getElementById('scrollIndicator');
        const dropdownOverlay = document.getElementById('dropdownOverlay');

        // Dropdown initialization for date format and timezone
        function initDropdowns() {
            document.querySelectorAll('.dropdown').forEach(dropdown => {
                const toggle = dropdown.querySelector('.dropdown-toggle');
                const menu = dropdown.querySelector('.dropdown-menu');
                const items = dropdown.querySelectorAll('.dropdown-item');
                const text = dropdown.querySelector('.dropdown-text');
                toggle.addEventListener('click', function(e) {
                    e.stopPropagation();
                    document.querySelectorAll('.dropdown-menu').forEach(m => m.classList.remove('show'));
                    menu.classList.toggle('show');
                });
                items.forEach(item => {
                    item.addEventListener('click', function(e) {
                        items.forEach(i => i.classList.remove('selected'));
                        item.classList.add('selected');
                        text.textContent = item.textContent;
                        menu.classList.remove('show');
                        if (dropdown.id === 'dateFormatDropdown') {
                            currentDateFormat = item.getAttribute('data-value');
                            renderEvents();
                        }
                        if (dropdown.id === 'timezoneDropdown') {
                            currentTimezone = item.textContent;
                        }
                    });
                });
            });
            document.addEventListener('click', function() {
                document.querySelectorAll('.dropdown-menu').forEach(m => m.classList.remove('show'));
            });
        }

        document.addEventListener('DOMContentLoaded', function() {
            initDropdowns();
        });

        // Scroll indicator
        window.addEventListener('scroll', () => {
            const scrolled = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
            scrollIndicator.style.width = Math.max(0, Math.min(100, scrolled)) + '%';
        });

        // Enhanced Dropdown functionality
        function initDropdowns() {
            const dropdowns = document.querySelectorAll('.dropdown');
            
            dropdowns.forEach(dropdown => {
                const toggle = dropdown.querySelector('.dropdown-toggle');
                const menu = dropdown.querySelector('.dropdown-menu');
                const items = dropdown.querySelectorAll('.dropdown-item');
                const text = dropdown.querySelector('.dropdown-text');
                const arrow = dropdown.querySelector('.dropdown-arrow');
                
                // Toggle dropdown
                toggle.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    // Close other dropdowns
                    closeAllDropdowns();
                    
                    // Toggle current dropdown
                    const isOpen = menu.classList.contains('show');
                    if (!isOpen) {
                        openDropdown(dropdown);
                    }
                });
                
                // Handle item selection
                items.forEach(item => {
                    item.addEventListener('click', (e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        
                        // Remove selected class from all items
                        items.forEach(i => i.classList.remove('selected'));
                        
                        // Add selected class to clicked item
                        item.classList.add('selected');
                        
                        // Update display text
                        const selectedText = item.textContent.trim();
                        text.textContent = selectedText;
                        
                        // Store the value
                        const value = item.getAttribute('data-value') || selectedText;
                        dropdown.setAttribute('data-selected', value);
                        
                        // Close dropdown
                        closeDropdown(dropdown);
                        
                        // Trigger change event
                        handleDropdownChange(dropdown.id, value, selectedText);
                    });
                    
                    // Hover effects
                    item.addEventListener('mouseenter', () => {
                        items.forEach(i => i.style.background = '');
                        item.style.background = '#f3f4f6';
                    });
                    
                    item.addEventListener('mouseleave', () => {
                        if (!item.classList.contains('selected')) {
                            item.style.background = '';
                        }
                    });
                });
            });
            
            // Close dropdowns when clicking outside
            document.addEventListener('click', (e) => {
                if (!e.target.closest('.dropdown')) {
                    closeAllDropdowns();
                }
            });
            
            // Close dropdowns on escape key
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    closeAllDropdowns();
                }
            });
            
            // Handle overlay click
            dropdownOverlay.addEventListener('click', closeAllDropdowns);
        }

        function openDropdown(dropdown) {
            const toggle = dropdown.querySelector('.dropdown-toggle');
            const menu = dropdown.querySelector('.dropdown-menu');
            
            toggle.classList.add('active');
            menu.classList.add('show');
            dropdownOverlay.classList.add('show');
            
            // Focus management for accessibility
            const firstItem = menu.querySelector('.dropdown-item');
            if (firstItem) {
                firstItem.focus();
            }
        }

        function closeDropdown(dropdown) {
            const toggle = dropdown.querySelector('.dropdown-toggle');
            const menu = dropdown.querySelector('.dropdown-menu');
            
            toggle.classList.remove('active');
            menu.classList.remove('show');
        }

        function closeAllDropdowns() {
            const dropdowns = document.querySelectorAll('.dropdown');
            dropdowns.forEach(dropdown => {
                closeDropdown(dropdown);
            });
            dropdownOverlay.classList.remove('show');
        }

        function handleDropdownChange(dropdownId, value, text) {
            console.log(`Dropdown ${dropdownId} changed to: ${value} (${text})`);
            
            switch(dropdownId) {
                case 'timezoneDropdown':
                    currentTimezone = text;
                    console.log('Timezone changed to:', currentTimezone);
                    break;
                case 'dateFormatDropdown':
                    currentDateFormat = value;
                    console.log('Date format changed to:', currentDateFormat);
                    renderEvents(); // Re-render events with new date format
                    break;
            }
        }

        // Toggle buttons
        function initToggleButtons() {
            const toggle12h = document.getElementById('toggle12h');
            const toggle24h = document.getElementById('toggle24h');
            
            toggle12h.addEventListener('click', () => {
                toggle12h.classList.add('active');
                toggle24h.classList.remove('active');
                timeFormat = '12H';
                renderEvents(); // Re-render with new time format
            });
            
            toggle24h.addEventListener('click', () => {
                toggle24h.classList.add('active');
                toggle12h.classList.remove('active');
                timeFormat = '24H';
                renderEvents(); // Re-render with new time format
            });
        }

        // Modal functionality
        function openModal() {
            newEventModal.classList.add('show');
            document.body.style.overflow = 'hidden';
            document.getElementById('eventTitle').focus();
        }

        function closeModalFunc() {
            newEventModal.classList.remove('show');
            document.body.style.overflow = 'auto';
            eventForm.reset();
            delete eventForm.dataset.editingId;
        }

        // Event management
        function addEvent(eventData) {
            const event = {
                id: Date.now(),
                title: eventData.title,
                startDate: new Date(eventData.startDate),
                endDate: eventData.endDate ? new Date(eventData.endDate) : null,
                description: eventData.description,
                location: eventData.location,
                category: eventData.category,
                completed: false
            };
            
            events.push(event);
            renderEvents();
            updateCounts();
        }


        function renderEvents() {
            if (events.length === 0) {
                tableBody.innerHTML = '<div style="padding: 40px; text-align: center; color: #6b7280;">No events found. Click "New" to create your first event.</div>';
                return;
            }

            const filteredEvents = filterEvents();
            const sortedEvents = sortEvents(filteredEvents);
            
            tableBody.innerHTML = sortedEvents.map(event => `
                <div style="display: grid; grid-template-columns: 60px 1fr 1fr 2fr 200px; gap: 16px; padding: 12px 16px; border-bottom: 1px solid #e5e7eb; align-items: center;">
                    <input type="checkbox" style="margin: 0;" data-event-id="${event.id}">
                    <div>${formatDate(event.startDate)}</div>
                    <div>${event.endDate ? formatDate(event.endDate) : '-'}</div>
                    <div>
                        <div style="font-weight: 500;">${event.title}</div>
                        ${event.location ? `<div style="font-size: 12px; color: #6b7280;">📍 ${event.location}</div>` : ''}
                        ${event.category ? `<div style="font-size: 11px; color: #6b7280; text-transform: uppercase;">${event.category}</div>` : ''}
                    </div>
                    <div style="display: flex; gap: 8px;">
                        <button class="btn btn-outline" style="padding: 4px 8px; font-size: 12px;" onclick="editEvent(${event.id})">Edit</button>
                        <button class="btn btn-danger" style="padding: 4px 8px; font-size: 12px;" onclick="deleteEvent(${event.id})">Delete</button>
                    </div>
                </div>
            `).join('');
        }

        function filterEvents() {
            const filterText = filterInput.value.toLowerCase();
            if (!filterText) return events;
            
            return events.filter(event => 
                event.title.toLowerCase().includes(filterText) ||
                (event.description && event.description.toLowerCase().includes(filterText)) ||
                (event.location && event.location.toLowerCase().includes(filterText)) ||
                (event.category && event.category.toLowerCase().includes(filterText))
            );
        }

        function sortEvents(eventsToSort) {
            return [...eventsToSort].sort((a, b) => {
                let aValue = a[currentSort.field];
                let bValue = b[currentSort.field];
                
                if (currentSort.field === 'date') {
                    aValue = a.startDate;
                    bValue = b.startDate;
                }
                
                if (aValue < bValue) return currentSort.direction === 'asc' ? -1 : 1;
                if (aValue > bValue) return currentSort.direction === 'asc' ? 1 : -1;
                return 0;
            });
        }

        function formatDate(date) {
            const options = { 
                year: 'numeric', 
                month: '2-digit', 
                day: '2-digit',
                hour: timeFormat === '12H' ? 'numeric' : '2-digit',
                minute: '2-digit',
                hour12: timeFormat === '12H'
            };
            
            let formatted = date.toLocaleDateString('en-US', options);
            
            // Apply date format
            if (currentDateFormat === 'DD/MM/YYYY') {
                const parts = formatted.split(',');
                if (parts.length >= 2) {
                    const datePart = parts[0].split('/');
                    if (datePart.length === 3) {
                        formatted = `${datePart[1]}/${datePart[0]}/${datePart[2]}${parts[1]}`;
                    }
                }
            }
            
            return formatted;
        }

        function updateCounts() {
            document.getElementById('totalCount').textContent = events.length;
            document.getElementById('eventCount').textContent = events.length;
            document.getElementById('completedCount').textContent = events.filter(e => e.completed).length;
        }

        function deleteEvent(id) {
            if (confirm('Are you sure you want to delete this event?')) {
                events = events.filter(event => event.id !== id);
                renderEvents();
                updateCounts();
            }
        }

        function editEvent(id) {
            const event = events.find(e => e.id === id);
            if (event) {
                document.getElementById('eventTitle').value = event.title;
                document.getElementById('eventDate').value = event.startDate.toISOString().slice(0, 16);
                if (event.endDate) {
                    document.getElementById('eventEndDate').value = event.endDate.toISOString().slice(0, 16);
                }
                document.getElementById('eventDescription').value = event.description || '';
                document.getElementById('eventLocation').value = event.location || '';
                document.getElementById('eventCategory').value = event.category || 'meeting';
                
                // Store the ID for updating
                eventForm.dataset.editingId = id;
                openModal();
            }
        }

        // Event listeners
        newEventBtn.addEventListener('click', openModal);
        closeModal.addEventListener('click', closeModalFunc);
        cancelBtn.addEventListener('click', closeModalFunc);

        // Close modal when clicking outside
        newEventModal.addEventListener('click', (e) => {
            if (e.target === newEventModal) {
                closeModalFunc();
            }
        });

        // Form submission
        saveEventBtn.addEventListener('click', (e) => {
            e.preventDefault();
            
            const eventData = {
                title: document.getElementById('eventTitle').value,
                startDate: document.getElementById('eventDate').value,
                endDate: document.getElementById('eventEndDate').value,
                description: document.getElementById('eventDescription').value,
                location: document.getElementById('eventLocation').value,
                category: document.getElementById('eventCategory').value
            };
            
            if (!eventData.title || !eventData.startDate) {
                alert('Please fill in the required fields (Title and Start Date)');
                return;
            }
            
            if (eventForm.dataset.editingId) {
                // Update existing event
                const id = parseInt(eventForm.dataset.editingId);
                const eventIndex = events.findIndex(e => e.id === id);
                if (eventIndex !== -1) {
                    events[eventIndex] = {
                        ...events[eventIndex],
                        title: eventData.title,
                        startDate: new Date(eventData.startDate),
                        endDate: eventData.endDate ? new Date(eventData.endDate) : null,
                        description: eventData.description,
                        location: eventData.location,
                        category: eventData.category
                    };
                }
                delete eventForm.dataset.editingId;
            } else {
                // Add new event
                addEvent(eventData);
            }
            
            closeModalFunc();
        });

        // Filter functionality
        filterInput.addEventListener('input', renderEvents);

        // Sort functionality
        document.getElementById('sortDate').addEventListener('click', () => {
            if (currentSort.field === 'date') {
                currentSort.direction = currentSort.direction === 'asc' ? 'desc' : 'asc';
            } else {
                currentSort.field = 'date';
                currentSort.direction = 'asc';
            }
            renderEvents();
        });

        // Button click handlers
        document.getElementById('exportBtn').addEventListener('click', () => {
            if (events.length === 0) {
                alert('No events to export');
                return;
            }
            alert(`Exporting ${events.length} events...`);
        });

        document.getElementById('loadBtn').addEventListener('click', () => {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = '.ics';
            input.onchange = (e) => {
                const file = e.target.files[0];
                if (file) {
                    alert(`Loading file: ${file.name}`);
                }
            };
            input.click();
        });

        document.getElementById('deleteBtn').addEventListener('click', () => {
            const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
            if (checkboxes.length === 0) {
                alert('Please select events to delete');
                return;
            }
            if (confirm(`Delete ${checkboxes.length} selected event(s)?`)) {
                checkboxes.forEach(checkbox => {
                    const eventId = parseInt(checkbox.getAttribute('data-event-id'));
                    events = events.filter(event => event.id !== eventId);
                });
                renderEvents();
                updateCounts();
            }
        });

        document.getElementById('optionsBtn').addEventListener('click', () => {
            alert('Options panel would open here');
        });

        document.getElementById('hideDetailBtn').addEventListener('click', function() {
            this.textContent = this.textContent === 'Hide Detail' ? 'Show Detail' : 'Hide Detail';
            this.classList.toggle('btn-primary');
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 'n') {
                e.preventDefault();
                openModal();
            }
            if (e.key === 'Escape') {
                if (newEventModal.classList.contains('show')) {
                    closeModalFunc();
                } else {
                    closeAllDropdowns();
                }
            }
        });

        // Initialize
        initDropdowns();
        initToggleButtons();
        renderEvents();
        updateCounts();

        // Add some sample events for demonstration
        setTimeout(() => {
            addEvent({
                title: 'Team Meeting',
                startDate: new Date().toISOString().slice(0, 16),
                endDate: new Date(Date.now() + 3600000).toISOString().slice(0, 16),
                description: 'Weekly team sync',
                location: 'Conference Room A',
                category: 'meeting'
            });
            
            addEvent({
                title: 'Project Deadline',
                startDate: new Date(Date.now() + 86400000).toISOString().slice(0, 16),
                endDate: '',
                description: 'Final submission',
                location: '',
                category: 'work'
            });
        }, 1000);

        console.log('Event Manager initialized successfully!');