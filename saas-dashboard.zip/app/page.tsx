"use client"

import { useState } from "react"
import {
  AppWindow,
  CreditCard,
  Users,
  Calendar,
  Search,
  Building2,
  UserCircle,
  Activity,
  BarChart3,
  Lock,
  Menu,
  X,
  LayoutDashboard,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

// Import page components
import {
  DashboardOverview,
  ApplicationInventory,
  LicenseManagement,
  LicenseAssignment,
  RenewalCost,
  ShadowIT,
  VendorManagement,
  UserGroupMapping,
  ActivityScoring,
  DashboardReporting,
  SSOIntegration,
} from "./components"

export default function SaasManagementDashboard() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [activePage, setActivePage] = useState("dashboard")

  // Navigation items
  const navItems = [
    { id: "dashboard", name: "Dashboard", icon: LayoutDashboard },
    { id: "apps", name: "Application Inventory", icon: AppWindow },
    { id: "licenses", name: "License Management", icon: CreditCard },
    { id: "users", name: "License Assignment", icon: Users },
    { id: "renewals", name: "Renewal & Cost", icon: Calendar },
    { id: "shadowit", name: "Shadow IT Detection", icon: Search },
    { id: "vendors", name: "Vendor Management", icon: Building2 },
    { id: "groups", name: "User & Group Mapping", icon: UserCircle },
    { id: "activity", name: "Activity Scoring", icon: Activity },
    { id: "reports", name: "Dashboard & Reports", icon: BarChart3 },
    { id: "sso", name: "SSO Integration", icon: Lock },
  ]

  // Handle navigation click
  const handleNavClick = (pageId) => {
    setActivePage(pageId)
    setIsSidebarOpen(false) // Close sidebar on mobile after clicking
  }

  // Render the active page content
  const renderPageContent = () => {
    switch (activePage) {
      case "apps":
        return <ApplicationInventory />
      case "licenses":
        return <LicenseManagement />
      case "users":
        return <LicenseAssignment />
      case "renewals":
        return <RenewalCost />
      case "shadowit":
        return <ShadowIT />
      case "vendors":
        return <VendorManagement />
      case "groups":
        return <UserGroupMapping />
      case "activity":
        return <ActivityScoring />
      case "reports":
        return <DashboardReporting />
      case "sso":
        return <SSOIntegration />
      default:
        return <DashboardOverview />
    }
  }

  return (
    <div className="flex min-h-screen bg-background">
      {/* Mobile sidebar toggle */}
      <Button
        variant="ghost"
        size="icon"
        className="fixed top-4 left-4 z-50 md:hidden"
        onClick={() => setIsSidebarOpen(!isSidebarOpen)}
      >
        {isSidebarOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
      </Button>

      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-40 w-64 transform bg-card shadow-lg transition-transform duration-200 ease-in-out md:translate-x-0 ${
          isSidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex h-16 items-center border-b px-6">
          <h1 className="text-xl font-bold">SaaS Manager</h1>
        </div>
        <nav className="space-y-1 px-3 py-4">
          {navItems.map((item) => (
            <Button
              key={item.id}
              variant={activePage === item.id ? "default" : "ghost"}
              className={`w-full justify-start ${activePage === item.id ? "bg-primary text-primary-foreground" : ""}`}
              onClick={() => handleNavClick(item.id)}
            >
              <item.icon className="mr-2 h-5 w-5" />
              {item.name}
            </Button>
          ))}
        </nav>
      </div>

      {/* Main content */}
      <div className="flex-1 transition-all duration-200 ease-in-out md:ml-64">
        <header className="sticky top-0 z-30 flex h-16 items-center gap-4 border-b bg-background px-6">
          <div className="flex-1">
            <h1 className="text-xl font-bold md:text-2xl">
              {navItems.find((item) => item.id === activePage)?.name || "Dashboard"}
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <UserCircle className="mr-2 h-4 w-4" />
                  Admin
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>Profile</DropdownMenuItem>
                <DropdownMenuItem>Settings</DropdownMenuItem>
                <DropdownMenuItem>Logout</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        <main className="p-6">{renderPageContent()}</main>
      </div>
    </div>
  )
}
