"use client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { SearchIcon, Filter, Download, Plus, RefreshCw, Calendar, BarChart, CheckCircle, XCircle } from "lucide-react"

// Dashboard Overview Component
export function DashboardOverview() {
  return (
    <div className="space-y-6">
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Applications</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">127</div>
            <p className="text-xs text-muted-foreground">+5 this month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Active Licenses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,842</div>
            <p className="text-xs text-muted-foreground">+12% from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Monthly Cost</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$24,685</div>
            <p className="text-xs text-muted-foreground">+2.5% from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Upcoming Renewals</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8</div>
            <p className="text-xs text-muted-foreground">Next 30 days</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card className="col-span-1 lg:col-span-2">
          <CardHeader>
            <CardTitle>License Utilization</CardTitle>
            <CardDescription>Top applications by license usage</CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[300px]">
              <div className="space-y-4">
                {[
                  { name: "Microsoft 365", used: 342, total: 400, percent: 85 },
                  { name: "Salesforce", used: 156, total: 200, percent: 78 },
                  { name: "Slack", used: 287, total: 300, percent: 95 },
                  { name: "Adobe Creative Cloud", used: 98, total: 150, percent: 65 },
                  { name: "Zoom", used: 245, total: 250, percent: 98 },
                  { name: "Atlassian Suite", used: 178, total: 200, percent: 89 },
                  { name: "Dropbox", used: 134, total: 200, percent: 67 },
                  { name: "Google Workspace", used: 298, total: 300, percent: 99 },
                ].map((app) => (
                  <div key={app.name} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">{app.name}</div>
                      <div className="text-sm text-muted-foreground">
                        {app.used}/{app.total} ({app.percent}%)
                      </div>
                    </div>
                    <Progress value={app.percent} />
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Upcoming Renewals</CardTitle>
            <CardDescription>Next 30 days</CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[300px]">
              <div className="space-y-4">
                {[
                  { name: "Zoom", date: "May 22, 2025", cost: "$4,800" },
                  { name: "Slack", date: "May 28, 2025", cost: "$7,200" },
                  { name: "Asana", date: "June 3, 2025", cost: "$3,600" },
                  { name: "Notion", date: "June 5, 2025", cost: "$2,400" },
                  { name: "Figma", date: "June 8, 2025", cost: "$5,400" },
                  { name: "Miro", date: "June 10, 2025", cost: "$1,800" },
                  { name: "Airtable", date: "June 12, 2025", cost: "$3,000" },
                  { name: "Monday.com", date: "June 15, 2025", cost: "$6,000" },
                ].map((renewal) => (
                  <div key={renewal.name} className="flex items-center justify-between rounded-lg border p-3">
                    <div>
                      <div className="font-medium">{renewal.name}</div>
                      <div className="text-sm text-muted-foreground">{renewal.date}</div>
                    </div>
                    <div className="font-medium">{renewal.cost}</div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recently Discovered Shadow IT</CardTitle>
          <CardDescription>Applications detected in the last 30 days</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Application</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Discovered</TableHead>
                <TableHead>Users</TableHead>
                <TableHead>Risk Score</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[
                {
                  name: "Canva",
                  category: "Design",
                  date: "May 10, 2025",
                  users: 12,
                  risk: "Medium",
                  status: "Pending Review",
                },
                {
                  name: "Loom",
                  category: "Video",
                  date: "May 8, 2025",
                  users: 8,
                  risk: "Low",
                  status: "Approved",
                },
                {
                  name: "Calendly",
                  category: "Scheduling",
                  date: "May 5, 2025",
                  users: 15,
                  risk: "Low",
                  status: "Approved",
                },
                {
                  name: "Miro",
                  category: "Collaboration",
                  date: "May 3, 2025",
                  users: 23,
                  risk: "Low",
                  status: "Approved",
                },
                {
                  name: "ChatGPT",
                  category: "AI",
                  date: "April 28, 2025",
                  users: 34,
                  risk: "High",
                  status: "Restricted",
                },
              ].map((app) => (
                <TableRow key={app.name}>
                  <TableCell className="font-medium">{app.name}</TableCell>
                  <TableCell>{app.category}</TableCell>
                  <TableCell>{app.date}</TableCell>
                  <TableCell>{app.users}</TableCell>
                  <TableCell>
                    <Badge
                      variant={app.risk === "High" ? "destructive" : app.risk === "Medium" ? "secondary" : "outline"}
                    >
                      {app.risk}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        app.status === "Approved"
                          ? "success"
                          : app.status === "Restricted"
                            ? "destructive"
                            : "secondary"
                      }
                    >
                      {app.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

// Application Inventory Component
export function ApplicationInventory() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <CardTitle>Application Inventory</CardTitle>
              <CardDescription>Manage all your SaaS applications</CardDescription>
            </div>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Application
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 mb-4">
            <div className="relative w-full sm:max-w-sm">
              <SearchIcon className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search applications..." className="pl-8" />
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline">
                  <Filter className="mr-2 h-4 w-4" />
                  Filter
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem>All Categories</DropdownMenuItem>
                <DropdownMenuItem>Productivity</DropdownMenuItem>
                <DropdownMenuItem>Communication</DropdownMenuItem>
                <DropdownMenuItem>Design</DropdownMenuItem>
                <DropdownMenuItem>Development</DropdownMenuItem>
                <DropdownMenuItem>Marketing</DropdownMenuItem>
                <DropdownMenuItem>HR</DropdownMenuItem>
                <DropdownMenuItem>Finance</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Application</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Vendor</TableHead>
                  <TableHead className="hidden md:table-cell">Users</TableHead>
                  <TableHead className="hidden md:table-cell">SSO</TableHead>
                  <TableHead className="hidden md:table-cell">Risk Score</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {[
                  {
                    name: "Microsoft 365",
                    category: "Productivity",
                    vendor: "Microsoft",
                    users: 400,
                    sso: "SAML",
                    risk: "Low",
                    status: "Active",
                  },
                  {
                    name: "Salesforce",
                    category: "CRM",
                    vendor: "Salesforce",
                    users: 200,
                    sso: "SAML",
                    risk: "Low",
                    status: "Active",
                  },
                  {
                    name: "Slack",
                    category: "Communication",
                    vendor: "Salesforce",
                    users: 300,
                    sso: "SAML",
                    risk: "Low",
                    status: "Active",
                  },
                  {
                    name: "Adobe Creative Cloud",
                    category: "Design",
                    vendor: "Adobe",
                    users: 150,
                    sso: "SAML",
                    risk: "Low",
                    status: "Active",
                  },
                  {
                    name: "Zoom",
                    category: "Communication",
                    vendor: "Zoom",
                    users: 250,
                    sso: "OAuth",
                    risk: "Low",
                    status: "Active",
                  },
                ].map((app) => (
                  <TableRow key={app.name}>
                    <TableCell className="font-medium">{app.name}</TableCell>
                    <TableCell>{app.category}</TableCell>
                    <TableCell>{app.vendor}</TableCell>
                    <TableCell className="hidden md:table-cell">{app.users}</TableCell>
                    <TableCell className="hidden md:table-cell">{app.sso}</TableCell>
                    <TableCell className="hidden md:table-cell">
                      <Badge
                        variant={app.risk === "High" ? "destructive" : app.risk === "Medium" ? "secondary" : "outline"}
                      >
                        {app.risk}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="success">{app.status}</Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              className="h-4 w-4"
                            >
                              <circle cx="12" cy="12" r="1" />
                              <circle cx="12" cy="5" r="1" />
                              <circle cx="12" cy="19" r="1" />
                            </svg>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>View Details</DropdownMenuItem>
                          <DropdownMenuItem>Edit</DropdownMenuItem>
                          <DropdownMenuItem>Manage Licenses</DropdownMenuItem>
                          <DropdownMenuItem>View Users</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// License Management Component
export function LicenseManagement() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <CardTitle>License Management</CardTitle>
              <CardDescription>Track and manage all your SaaS licenses</CardDescription>
            </div>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add License
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 mb-4">
            <div className="relative w-full sm:max-w-sm">
              <SearchIcon className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search licenses..." className="pl-8" />
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline">
                  <Filter className="mr-2 h-4 w-4" />
                  Filter
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem>All Applications</DropdownMenuItem>
                <DropdownMenuItem>Microsoft 365</DropdownMenuItem>
                <DropdownMenuItem>Salesforce</DropdownMenuItem>
                <DropdownMenuItem>Slack</DropdownMenuItem>
                <DropdownMenuItem>Adobe Creative Cloud</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Application</TableHead>
                  <TableHead>Plan</TableHead>
                  <TableHead className="hidden md:table-cell">Quantity</TableHead>
                  <TableHead className="hidden md:table-cell">Used</TableHead>
                  <TableHead>Cost</TableHead>
                  <TableHead className="hidden md:table-cell">Renewal Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {[
                  {
                    name: "Microsoft 365",
                    plan: "Business Premium",
                    quantity: 400,
                    used: 342,
                    cost: "$20/user/mo",
                    renewal: "July 15, 2025",
                    status: "Active",
                  },
                  {
                    name: "Salesforce",
                    plan: "Enterprise",
                    quantity: 200,
                    used: 156,
                    cost: "$150/user/mo",
                    renewal: "August 22, 2025",
                    status: "Active",
                  },
                  {
                    name: "Slack",
                    plan: "Business+",
                    quantity: 300,
                    used: 287,
                    cost: "$12.50/user/mo",
                    renewal: "May 28, 2025",
                    status: "Active",
                  },
                  {
                    name: "Adobe Creative Cloud",
                    plan: "Teams",
                    quantity: 150,
                    used: 98,
                    cost: "$79.99/user/mo",
                    renewal: "September 10, 2025",
                    status: "Active",
                  },
                  {
                    name: "Zoom",
                    plan: "Business",
                    quantity: 250,
                    used: 245,
                    cost: "$19.99/user/mo",
                    renewal: "May 22, 2025",
                    status: "Active",
                  },
                ].map((license) => (
                  <TableRow key={`${license.name}-${license.plan}`}>
                    <TableCell className="font-medium">{license.name}</TableCell>
                    <TableCell>{license.plan}</TableCell>
                    <TableCell className="hidden md:table-cell">{license.quantity}</TableCell>
                    <TableCell className="hidden md:table-cell">{license.used}</TableCell>
                    <TableCell>{license.cost}</TableCell>
                    <TableCell className="hidden md:table-cell">{license.renewal}</TableCell>
                    <TableCell>
                      <Badge variant="success">{license.status}</Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              className="h-4 w-4"
                            >
                              <circle cx="12" cy="12" r="1" />
                              <circle cx="12" cy="5" r="1" />
                              <circle cx="12" cy="19" r="1" />
                            </svg>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>View Details</DropdownMenuItem>
                          <DropdownMenuItem>Edit</DropdownMenuItem>
                          <DropdownMenuItem>Manage Users</DropdownMenuItem>
                          <DropdownMenuItem>Renew License</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// License Assignment Component
export function LicenseAssignment() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <CardTitle>User Management</CardTitle>
              <CardDescription>Manage users and their application access</CardDescription>
            </div>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add User
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 mb-4">
            <div className="relative w-full sm:max-w-sm">
              <SearchIcon className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search users..." className="pl-8" />
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline">
                  <Filter className="mr-2 h-4 w-4" />
                  Filter
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem>All Departments</DropdownMenuItem>
                <DropdownMenuItem>Engineering</DropdownMenuItem>
                <DropdownMenuItem>Marketing</DropdownMenuItem>
                <DropdownMenuItem>Sales</DropdownMenuItem>
                <DropdownMenuItem>HR</DropdownMenuItem>
                <DropdownMenuItem>Finance</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead className="hidden md:table-cell">Apps</TableHead>
                  <TableHead className="hidden md:table-cell">Last Active</TableHead>
                  <TableHead>Activity Score</TableHead>
                  <TableHead className="hidden md:table-cell">Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {[
                  {
                    name: "John Smith",
                    email: "john.smith@company.com",
                    department: "Engineering",
                    apps: 8,
                    lastActive: "Today",
                    score: "High",
                    status: "Active",
                  },
                  {
                    name: "Sarah Johnson",
                    email: "sarah.johnson@company.com",
                    department: "Marketing",
                    apps: 12,
                    lastActive: "Today",
                    score: "High",
                    status: "Active",
                  },
                  {
                    name: "Michael Brown",
                    email: "michael.brown@company.com",
                    department: "Sales",
                    apps: 6,
                    lastActive: "Yesterday",
                    score: "Medium",
                    status: "Active",
                  },
                  {
                    name: "Emily Davis",
                    email: "emily.davis@company.com",
                    department: "HR",
                    apps: 5,
                    lastActive: "3 days ago",
                    score: "Medium",
                    status: "Active",
                  },
                  {
                    name: "David Wilson",
                    email: "david.wilson@company.com",
                    department: "Finance",
                    apps: 7,
                    lastActive: "Today",
                    score: "High",
                    status: "Active",
                  },
                ].map((user) => (
                  <TableRow key={user.email}>
                    <TableCell className="font-medium">{user.name}</TableCell>
                    <TableCell>{user.email}</TableCell>
                    <TableCell>{user.department}</TableCell>
                    <TableCell className="hidden md:table-cell">{user.apps}</TableCell>
                    <TableCell className="hidden md:table-cell">{user.lastActive}</TableCell>
                    <TableCell>
                      <Badge
                        variant={
                          user.score === "High" ? "success" : user.score === "Medium" ? "secondary" : "destructive"
                        }
                      >
                        {user.score}
                      </Badge>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      <Badge variant="success">{user.status}</Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              className="h-4 w-4"
                            >
                              <circle cx="12" cy="12" r="1" />
                              <circle cx="12" cy="5" r="1" />
                              <circle cx="12" cy="19" r="1" />
                            </svg>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>View Profile</DropdownMenuItem>
                          <DropdownMenuItem>Edit</DropdownMenuItem>
                          <DropdownMenuItem>Manage Apps</DropdownMenuItem>
                          <DropdownMenuItem>View Activity</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// Renewal & Cost Tracking Component
export function RenewalCost() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h2 className="text-2xl font-bold">Renewal & Cost Tracking</h2>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Calendar className="mr-2 h-4 w-4" />
            Calendar View
          </Button>
          <Button variant="outline">
            <BarChart className="mr-2 h-4 w-4" />
            Cost Analysis
          </Button>
        </div>
      </div>

      <Tabs defaultValue="upcoming">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="upcoming">Upcoming Renewals</TabsTrigger>
          <TabsTrigger value="active">Active Licenses</TabsTrigger>
          <TabsTrigger value="expired">Expired</TabsTrigger>
        </TabsList>
        <TabsContent value="upcoming" className="mt-4">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Application</TableHead>
                    <TableHead>Plan</TableHead>
                    <TableHead>Expiry Date</TableHead>
                    <TableHead>Total Cost</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {[
                    { app: "Zoom", plan: "Business", expiry: "May 22, 2025", cost: "$4,800", status: "Pending" },
                    { app: "Slack", plan: "Business+", expiry: "May 28, 2025", cost: "$7,200", status: "Pending" },
                    { app: "Asana", plan: "Premium", expiry: "June 3, 2025", cost: "$3,600", status: "Pending" },
                    { app: "Notion", plan: "Team", expiry: "June 5, 2025", cost: "$2,400", status: "Pending" },
                  ].map((renewal) => (
                    <TableRow key={renewal.app}>
                      <TableCell className="font-medium">{renewal.app}</TableCell>
                      <TableCell>{renewal.plan}</TableCell>
                      <TableCell>{renewal.expiry}</TableCell>
                      <TableCell>{renewal.cost}</TableCell>
                      <TableCell>
                        <Badge variant="secondary">Pending Renewal</Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="outline" size="sm">
                          Renew
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="active" className="mt-4">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Application</TableHead>
                    <TableHead>Plan</TableHead>
                    <TableHead>Expiry Date</TableHead>
                    <TableHead>Total Cost</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {[
                    {
                      app: "Microsoft 365",
                      plan: "Business Premium",
                      expiry: "July 15, 2025",
                      cost: "$8,000",
                      status: "Active",
                    },
                    {
                      app: "Salesforce",
                      plan: "Enterprise",
                      expiry: "August 22, 2025",
                      cost: "$30,000",
                      status: "Active",
                    },
                    {
                      app: "Adobe Creative Cloud",
                      plan: "Teams",
                      expiry: "September 10, 2025",
                      cost: "$12,000",
                      status: "Active",
                    },
                    {
                      app: "Atlassian Suite",
                      plan: "Standard",
                      expiry: "October 5, 2025",
                      cost: "$1,400",
                      status: "Active",
                    },
                  ].map((renewal) => (
                    <TableRow key={renewal.app}>
                      <TableCell className="font-medium">{renewal.app}</TableCell>
                      <TableCell>{renewal.plan}</TableCell>
                      <TableCell>{renewal.expiry}</TableCell>
                      <TableCell>{renewal.cost}</TableCell>
                      <TableCell>
                        <Badge variant="success">Active</Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          View Details
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="expired" className="mt-4">
          <Card>
            <CardContent className="p-6 text-center">
              <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-muted">
                <CheckCircle className="h-10 w-10 text-muted-foreground" />
              </div>
              <h3 className="mt-4 text-lg font-medium">No Expired Licenses</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                All your licenses are currently active or pending renewal.
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle>Monthly Cost Breakdown</CardTitle>
          <CardDescription>Total cost by application category</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between">
                <div className="text-sm font-medium">Communication</div>
                <div className="text-sm text-muted-foreground">$12,000</div>
              </div>
              <Progress value={35} className="h-2 mt-2" />
            </div>
            <div>
              <div className="flex items-center justify-between">
                <div className="text-sm font-medium">Productivity</div>
                <div className="text-sm text-muted-foreground">$8,000</div>
              </div>
              <Progress value={25} className="h-2 mt-2" />
            </div>
            <div>
              <div className="flex items-center justify-between">
                <div className="text-sm font-medium">Design</div>
                <div className="text-sm text-muted-foreground">$12,000</div>
              </div>
              <Progress value={35} className="h-2 mt-2" />
            </div>
            <div>
              <div className="flex items-center justify-between">
                <div className="text-sm font-medium">CRM</div>
                <div className="text-sm text-muted-foreground">$30,000</div>
              </div>
              <Progress value={85} className="h-2 mt-2" />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// Shadow IT Detection Component
export function ShadowIT() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h2 className="text-2xl font-bold">Shadow IT Detection</h2>
        <Button>
          <SearchIcon className="mr-2 h-4 w-4" />
          Scan for New Apps
        </Button>
      </div>

      <Tabs defaultValue="detected">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="detected">Newly Detected</TabsTrigger>
          <TabsTrigger value="reviewed">Under Review</TabsTrigger>
          <TabsTrigger value="approved">Approved</TabsTrigger>
        </TabsList>
        <TabsContent value="detected" className="mt-4">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Application</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Discovered</TableHead>
                    <TableHead>Users</TableHead>
                    <TableHead>Risk Score</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {[
                    {
                      name: "Canva",
                      category: "Design",
                      date: "May 10, 2025",
                      users: 12,
                      risk: "Medium",
                    },
                    {
                      name: "ChatGPT",
                      category: "AI",
                      date: "April 28, 2025",
                      users: 34,
                      risk: "High",
                    },
                  ].map((app) => (
                    <TableRow key={app.name}>
                      <TableCell className="font-medium">{app.name}</TableCell>
                      <TableCell>{app.category}</TableCell>
                      <TableCell>{app.date}</TableCell>
                      <TableCell>{app.users}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            app.risk === "High" ? "destructive" : app.risk === "Medium" ? "secondary" : "outline"
                          }
                        >
                          {app.risk}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="outline" size="sm" className="mr-2">
                          Review
                        </Button>
                        <Button variant="ghost" size="sm">
                          Ignore
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="reviewed" className="mt-4">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Application</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Discovered</TableHead>
                    <TableHead>Users</TableHead>
                    <TableHead>Risk Score</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {[
                    {
                      name: "Miro",
                      category: "Collaboration",
                      date: "May 3, 2025",
                      users: 23,
                      risk: "Low",
                    },
                  ].map((app) => (
                    <TableRow key={app.name}>
                      <TableCell className="font-medium">{app.name}</TableCell>
                      <TableCell>{app.category}</TableCell>
                      <TableCell>{app.date}</TableCell>
                      <TableCell>{app.users}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            app.risk === "High" ? "destructive" : app.risk === "Medium" ? "secondary" : "outline"
                          }
                        >
                          {app.risk}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="outline" size="sm" className="mr-2">
                          Approve
                        </Button>
                        <Button variant="ghost" size="sm">
                          Reject
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="approved" className="mt-4">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Application</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Discovered</TableHead>
                    <TableHead>Users</TableHead>
                    <TableHead>Risk Score</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {[
                    {
                      name: "Loom",
                      category: "Video",
                      date: "May 8, 2025",
                      users: 8,
                      risk: "Low",
                    },
                    {
                      name: "Calendly",
                      category: "Scheduling",
                      date: "May 5, 2025",
                      users: 15,
                      risk: "Low",
                    },
                  ].map((app) => (
                    <TableRow key={app.name}>
                      <TableCell className="font-medium">{app.name}</TableCell>
                      <TableCell>{app.category}</TableCell>
                      <TableCell>{app.date}</TableCell>
                      <TableCell>{app.users}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            app.risk === "High" ? "destructive" : app.risk === "Medium" ? "secondary" : "outline"
                          }
                        >
                          {app.risk}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="outline" size="sm">
                          Add to Inventory
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

// Vendor Management Component
export function VendorManagement() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <CardTitle>Vendor Management</CardTitle>
              <CardDescription>Manage your SaaS vendors and contacts</CardDescription>
            </div>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Vendor
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 mb-4">
            <div className="relative w-full sm:max-w-sm">
              <SearchIcon className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search vendors..." className="pl-8" />
            </div>
          </div>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Vendor Name</TableHead>
                  <TableHead>Contact Email</TableHead>
                  <TableHead className="hidden md:table-cell">Phone</TableHead>
                  <TableHead>Associated Apps</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {[
                  {
                    name: "Microsoft",
                    email: "enterprise@microsoft.com",
                    phone: "+1-800-642-7676",
                    apps: ["Microsoft 365"],
                  },
                  {
                    name: "Salesforce",
                    email: "support@salesforce.com",
                    phone: "+1-800-667-6389",
                    apps: ["Salesforce", "Slack"],
                  },
                  {
                    name: "Adobe",
                    email: "enterprise@adobe.com",
                    phone: "+1-800-833-6687",
                    apps: ["Adobe Creative Cloud"],
                  },
                  {
                    name: "Zoom",
                    email: "support@zoom.us",
                    phone: "+1-888-799-9666",
                    apps: ["Zoom"],
                  },
                  {
                    name: "Atlassian",
                    email: "enterprise@atlassian.com",
                    phone: "+1-415-701-1110",
                    apps: ["Atlassian Suite"],
                  },
                ].map((vendor) => (
                  <TableRow key={vendor.name}>
                    <TableCell className="font-medium">{vendor.name}</TableCell>
                    <TableCell>{vendor.email}</TableCell>
                    <TableCell className="hidden md:table-cell">{vendor.phone}</TableCell>
                    <TableCell>
                      {vendor.apps.map((app) => (
                        <Badge key={app} variant="outline" className="mr-1">
                          {app}
                        </Badge>
                      ))}
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              className="h-4 w-4"
                            >
                              <circle cx="12" cy="12" r="1" />
                              <circle cx="12" cy="5" r="1" />
                              <circle cx="12" cy="19" r="1" />
                            </svg>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>View Details</DropdownMenuItem>
                          <DropdownMenuItem>Edit</DropdownMenuItem>
                          <DropdownMenuItem>Contact Vendor</DropdownMenuItem>
                          <DropdownMenuItem>View Apps</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// User & Group Mapping Component
export function UserGroupMapping() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h2 className="text-2xl font-bold">User & Group Mapping</h2>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Plus className="mr-2 h-4 w-4" />
            Add Group
          </Button>
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Add User
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Departments</CardTitle>
            <CardDescription>User distribution by department</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { name: "Engineering", users: 45, percent: 30 },
                { name: "Marketing", users: 28, percent: 19 },
                { name: "Sales", users: 35, percent: 23 },
                { name: "Design", users: 18, percent: 12 },
                { name: "Finance", users: 12, percent: 8 },
                { name: "HR", users: 8, percent: 5 },
                { name: "Product", users: 15, percent: 10 },
              ].map((dept) => (
                <div key={dept.name}>
                  <div className="flex items-center justify-between">
                    <div className="text-sm font-medium">{dept.name}</div>
                    <div className="text-sm text-muted-foreground">{dept.users} users</div>
                  </div>
                  <Progress value={dept.percent} className="h-2 mt-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>License Distribution</CardTitle>
            <CardDescription>License allocation by department</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { name: "Engineering", licenses: 135, percent: 28 },
                { name: "Marketing", licenses: 112, percent: 23 },
                { name: "Sales", licenses: 105, percent: 22 },
                { name: "Design", licenses: 72, percent: 15 },
                { name: "Finance", licenses: 36, percent: 7 },
                { name: "HR", licenses: 24, percent: 5 },
                { name: "Product", licenses: 45, percent: 9 },
              ].map((dept) => (
                <div key={dept.name}>
                  <div className="flex items-center justify-between">
                    <div className="text-sm font-medium">{dept.name}</div>
                    <div className="text-sm text-muted-foreground">{dept.licenses} licenses</div>
                  </div>
                  <Progress value={dept.percent} className="h-2 mt-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// Activity Scoring Component
export function ActivityScoring() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h2 className="text-2xl font-bold">Activity Scoring</h2>
        <Button variant="outline">
          <RefreshCw className="mr-2 h-4 w-4" />
          Refresh Data
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Average Activity Score</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">87%</div>
            <Progress value={87} className="h-2 mt-2" />
            <p className="text-xs text-muted-foreground mt-2">+3% from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Inactive Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">12</div>
            <p className="text-xs text-muted-foreground">Users with activity score below 50%</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Highly Active Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">85</div>
            <p className="text-xs text-muted-foreground">Users with activity score above 90%</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>User Activity Scores</CardTitle>
          <CardDescription>Activity scores for all users</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Department</TableHead>
                <TableHead className="hidden md:table-cell">Last Active</TableHead>
                <TableHead>Activity Score</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[
                {
                  name: "John Smith",
                  email: "john.smith@company.com",
                  department: "Engineering",
                  lastActive: "Today",
                  score: 95,
                },
                {
                  name: "Sarah Johnson",
                  email: "sarah.johnson@company.com",
                  department: "Marketing",
                  lastActive: "Today",
                  score: 92,
                },
                {
                  name: "Michael Brown",
                  email: "michael.brown@company.com",
                  department: "Sales",
                  lastActive: "Yesterday",
                  score: 78,
                },
                {
                  name: "Emily Davis",
                  email: "emily.davis@company.com",
                  department: "HR",
                  lastActive: "3 days ago",
                  score: 65,
                },
                {
                  name: "David Wilson",
                  email: "david.wilson@company.com",
                  department: "Finance",
                  lastActive: "Today",
                  score: 88,
                },
              ].map((user) => (
                <TableRow key={user.email}>
                  <TableCell className="font-medium">{user.name}</TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>{user.department}</TableCell>
                  <TableCell className="hidden md:table-cell">{user.lastActive}</TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <span
                        className={
                          user.score > 85 ? "text-green-600" : user.score > 70 ? "text-amber-600" : "text-red-600"
                        }
                      >
                        {user.score}%
                      </span>
                      <Progress
                        value={user.score}
                        className={`h-2 w-24 ml-2 ${
                          user.score > 85 ? "bg-green-100" : user.score > 70 ? "bg-amber-100" : "bg-red-100"
                        }`}
                      />
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">
                      View Details
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

// Dashboard & Reporting Component
export function DashboardReporting() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h2 className="text-2xl font-bold">Dashboard & Reporting</h2>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Export Reports
          </Button>
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Create Report
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>License Utilization</CardTitle>
            <CardDescription>Overall license usage</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center justify-center space-y-2">
              <div className="text-4xl font-bold">78%</div>
              <Progress value={78} className="h-2 w-full" />
              <p className="text-sm text-muted-foreground">980 of 1250 licenses in use</p>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" size="sm" className="w-full">
              View Details
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Cost Trends</CardTitle>
            <CardDescription>Monthly spending trends</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center justify-center space-y-2">
              <div className="text-4xl font-bold">$24,685</div>
              <div className="flex items-center text-green-600">
                <span className="text-sm">+8.5% from last month</span>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" size="sm" className="w-full">
              View Details
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Shadow IT</CardTitle>
            <CardDescription>Unauthorized app discoveries</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center justify-center space-y-2">
              <div className="text-4xl font-bold">5</div>
              <div className="flex items-center text-amber-600">
                <span className="text-sm">2 under review</span>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" size="sm" className="w-full">
              View Details
            </Button>
          </CardFooter>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Saved Reports</CardTitle>
          <CardDescription>Your custom and scheduled reports</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between rounded-lg border p-4">
              <div>
                <h3 className="font-medium">Monthly License Utilization</h3>
                <p className="text-sm text-muted-foreground">Last generated: May 14, 2025</p>
              </div>
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  Download
                </Button>
                <Button size="sm">View</Button>
              </div>
            </div>
            <div className="flex items-center justify-between rounded-lg border p-4">
              <div>
                <h3 className="font-medium">Quarterly Cost Analysis</h3>
                <p className="text-sm text-muted-foreground">Last generated: April 1, 2025</p>
              </div>
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  Download
                </Button>
                <Button size="sm">View</Button>
              </div>
            </div>
            <div className="flex items-center justify-between rounded-lg border p-4">
              <div>
                <h3 className="font-medium">User Activity Report</h3>
                <p className="text-sm text-muted-foreground">Last generated: May 10, 2025</p>
              </div>
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  Download
                </Button>
                <Button size="sm">View</Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// SSO Integration Component
export function SSOIntegration() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h2 className="text-2xl font-bold">SSO Integration</h2>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Add Integration
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Identity Provider Connections</CardTitle>
          <CardDescription>Connect to your identity providers</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between rounded-lg border p-4">
              <div className="flex items-center space-x-4">
                <div className="rounded-md bg-primary/10 p-2">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Authentik</h3>
                  <p className="text-sm text-muted-foreground">Connected on April 15, 2025</p>
                </div>
              </div>
              <Badge variant="outline">Active</Badge>
            </div>
            <div className="flex items-center justify-between rounded-lg border p-4">
              <div className="flex items-center space-x-4">
                <div className="rounded-md bg-primary/10 p-2">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Okta</h3>
                  <p className="text-sm text-muted-foreground">Connected on March 10, 2025</p>
                </div>
              </div>
              <Badge variant="outline">Active</Badge>
            </div>
            <div className="flex items-center justify-between rounded-lg border p-4">
              <div className="flex items-center space-x-4">
                <div className="rounded-md bg-muted p-2">
                  <XCircle className="h-6 w-6 text-muted-foreground" />
                </div>
                <div>
                  <h3 className="font-medium">Azure AD</h3>
                  <p className="text-sm text-muted-foreground">Not connected</p>
                </div>
              </div>
              <Button variant="outline" size="sm">
                Connect
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>SSO-Enabled Applications</CardTitle>
          <CardDescription>Applications using single sign-on</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Application</TableHead>
                <TableHead>SSO Type</TableHead>
                <TableHead>Identity Provider</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[
                { app: "Microsoft 365", type: "SAML", provider: "Authentik", status: "Active" },
                { app: "Salesforce", type: "SAML", provider: "Okta", status: "Active" },
                { app: "Slack", type: "SAML", provider: "Authentik", status: "Active" },
                { app: "Adobe Creative Cloud", type: "SAML", provider: "Okta", status: "Active" },
                { app: "Zoom", type: "OAuth", provider: "Authentik", status: "Active" },
              ].map((sso) => (
                <TableRow key={sso.app}>
                  <TableCell className="font-medium">{sso.app}</TableCell>
                  <TableCell>{sso.type}</TableCell>
                  <TableCell>{sso.provider}</TableCell>
                  <TableCell>
                    <Badge variant="success">{sso.status}</Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="outline" size="sm">
                      Configure
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
