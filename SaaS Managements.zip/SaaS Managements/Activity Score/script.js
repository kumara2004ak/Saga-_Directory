import { Chart } from "@/components/ui/chart"
document.addEventListener("DOMContentLoaded", () => {
  // Sample user data
  const users = [
    {
      id: 1,
      name: "Alex Johnson",
      email: "alex.j@example.com",
      department: "Engineering",
      apps: ["Slack", "GitHub", "Jira"],
      lastActive: "2 hours ago",
      activityScore: 92,
      loginFrequency: "Daily",
      licenseUsage: "85%",
    },
    {
      id: 2,
      name: "Sarah Williams",
      email: "sarah.w@example.com",
      department: "Marketing",
      apps: ["Slack", "HubSpot", "Google Workspace"],
      lastActive: "1 day ago",
      activityScore: 78,
      loginFrequency: "Daily",
      licenseUsage: "72%",
    },
    {
      id: 3,
      name: "Michael Brown",
      email: "michael.b@example.com",
      department: "Sales",
      apps: ["Salesforce", "Slack", "Zoom"],
      lastActive: "3 days ago",
      activityScore: 45,
      loginFrequency: "Weekly",
      licenseUsage: "38%",
    },
    {
      id: 4,
      name: "Emily Davis",
      email: "emily.d@example.com",
      department: "HR",
      apps: ["Workday", "Slack", "Google Workspace"],
      lastActive: "5 hours ago",
      activityScore: 88,
      loginFrequency: "Daily",
      licenseUsage: "90%",
    },
    {
      id: 5,
      name: "David Wilson",
      email: "david.w@example.com",
      department: "Engineering",
      apps: ["GitHub", "Jira", "Figma"],
      lastActive: "2 weeks ago",
      activityScore: 12,
      loginFrequency: "Rarely",
      licenseUsage: "5%",
    },
    {
      id: 6,
      name: "Jennifer Lee",
      email: "jennifer.l@example.com",
      department: "Product",
      apps: ["Figma", "Slack", "Notion"],
      lastActive: "1 hour ago",
      activityScore: 95,
      loginFrequency: "Daily",
      licenseUsage: "95%",
    },
    {
      id: 7,
      name: "Robert Taylor",
      email: "robert.t@example.com",
      department: "Finance",
      apps: ["QuickBooks", "Excel", "Slack"],
      lastActive: "4 days ago",
      activityScore: 62,
      loginFrequency: "Weekly",
      licenseUsage: "60%",
    },
  ]

  // Sample login data
  const loginData = [
    { date: "2023-05-10", time: "09:15 AM", source: "Web", duration: "4h 20m" },
    { date: "2023-05-09", time: "10:30 AM", source: "Mobile", duration: "2h 45m" },
    { date: "2023-05-08", time: "08:45 AM", source: "Web", duration: "5h 10m" },
    { date: "2023-05-05", time: "11:20 AM", source: "SSO", duration: "3h 30m" },
    { date: "2023-05-04", time: "09:00 AM", source: "Web", duration: "6h 15m" },
  ]

  // Sample historical data
  const historicalData = [
    { month: "Jan", score: 65 },
    { month: "Feb", score: 59 },
    { month: "Mar", score: 80 },
    { month: "Apr", score: 81 },
    { month: "May", score: 56 },
    { month: "Jun", score: 55 },
    { month: "Jul", score: 40 },
    { month: "Aug", score: 70 },
    { month: "Sep", score: 90 },
    { month: "Oct", score: 75 },
    { month: "Nov", score: 60 },
    { month: "Dec", score: 85 },
  ]

  // Sample data for the chart
  const chartData = {
    labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
    datasets: [
      {
        label: "Activity Score",
        data: [65, 59, 80, 81, 56, 55, 40, 70, 90, 75, 60, 85],
        borderColor: "#0ea5e9",
        backgroundColor: "rgba(14, 165, 233, 0.1)",
        tension: 0.3,
        fill: true,
      },
    ],
  }

  // Initialize the activity chart
  const activityChart = new Chart(document.getElementById("activity-chart"), {
    type: "line",
    data: chartData,
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
          max: 100,
          grid: {
            color: "rgba(0, 0, 0, 0.05)",
          },
        },
        x: {
          grid: {
            display: false,
          },
        },
      },
      plugins: {
        legend: {
          display: false,
        },
        tooltip: {
          mode: "index",
          intersect: false,
        },
      },
    },
  })

  // Sort state
  let sortField = "activityScore"
  let sortDirection = "desc"

  // Populate user table
  function populateUserTable() {
    const tableBody = document.getElementById("user-table-body")
    tableBody.innerHTML = ""

    // Sort users
    const sortedUsers = [...users].sort((a, b) => {
      if (sortDirection === "asc") {
        return a[sortField] > b[sortField] ? 1 : -1
      } else {
        return a[sortField] < b[sortField] ? 1 : -1
      }
    })

    sortedUsers.forEach((user) => {
      const row = document.createElement("tr")
      row.className = "border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer"
      row.setAttribute("data-user-id", user.id)

      // Get badge color based on activity score
      let badgeClass = "bg-red-500 text-white"
      if (user.activityScore >= 80) {
        badgeClass = "bg-green-500 text-white"
      } else if (user.activityScore >= 50) {
        badgeClass = "bg-yellow-500 text-white"
      }

      // Create user initials for avatar
      const initials = user.name
        .split(" ")
        .map((n) => n[0])
        .join("")

      row.innerHTML = `
        <td class="px-4 py-3">
          <div class="flex items-center gap-3">
            <div class="h-8 w-8 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center text-xs font-medium">
              ${initials}
            </div>
            <div>
              <div class="font-medium">${user.name}</div>
              <div class="text-xs text-gray-500 dark:text-gray-400">${user.email}</div>
            </div>
          </div>
        </td>
        <td class="px-4 py-3">${user.department}</td>
        <td class="px-4 py-3">${user.lastActive}</td>
        <td class="px-4 py-3">
          <div class="flex items-center gap-2">
            <div class="h-2 w-16 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
              <div class="h-full ${user.activityScore >= 80 ? "bg-green-500" : user.activityScore >= 50 ? "bg-yellow-500" : "bg-red-500"}" style="width: ${user.activityScore}%"></div>
            </div>
            <span class="text-sm font-medium">${user.activityScore}</span>
            <span class="inline-flex items-center rounded-full ${badgeClass} px-2.5 py-0.5 text-xs font-semibold">
              ${user.activityScore >= 80 ? "High" : user.activityScore >= 50 ? "Moderate" : "Low"}
            </span>
          </div>
        </td>
        <td class="px-4 py-3">
          <div class="relative inline-block text-left">
            <button class="rounded-md p-2 hover:bg-gray-100 dark:hover:bg-gray-700" onclick="event.stopPropagation()">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg>
            </button>
          </div>
        </td>
      `

      tableBody.appendChild(row)

      // Add click event to open user modal
      row.addEventListener("click", () => {
        openUserModal(user)
      })
    })
  }

  // Populate inactivity alerts
  function populateInactivityAlerts() {
    const alertsContainer = document.getElementById("inactivity-alerts")
    alertsContainer.innerHTML = ""

    // Filter users with low activity scores
    const inactiveUsers = users.filter((user) => user.activityScore < 50)

    inactiveUsers.forEach((user) => {
      const alertItem = document.createElement("div")
      alertItem.className =
        "flex items-center gap-4 rounded-lg border dark:border-gray-700 p-3 hover:bg-gray-50 dark:hover:bg-gray-700 mb-3"

      alertItem.innerHTML = `
        <div class="flex h-10 w-10 items-center justify-center rounded-full bg-red-100 dark:bg-red-900">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-red-600 dark:text-red-300"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>
        </div>
        <div class="flex-1">
          <div class="flex items-center justify-between">
            <div>
              <p class="font-medium">${user.name}</p>
              <p class="text-sm text-gray-500 dark:text-gray-400">${user.department} • Inactive for ${user.lastActive}</p>
            </div>
            <span class="inline-flex items-center rounded-full bg-red-500 px-2.5 py-0.5 text-xs font-semibold text-white">
              Score: ${user.activityScore}
            </span>
          </div>
        </div>
        <button class="rounded-md px-3 py-1 text-sm font-medium hover:bg-gray-100 dark:hover:bg-gray-700">
          Details
        </button>
      `

      alertsContainer.appendChild(alertItem)

      // Add click event to open user modal
      alertItem.addEventListener("click", () => {
        openUserModal(user)
      })
    })
  }

  // Open user modal
  function openUserModal(user) {
    const modal = document.getElementById("user-detail-modal")

    // Set user info
    document.getElementById("user-avatar").textContent = user.name
      .split(" ")
      .map((n) => n[0])
      .join("")
    document.getElementById("user-name").textContent = user.name
    document.getElementById("user-email").textContent = user.email
    document.getElementById("user-department").textContent = user.department
    document.getElementById("user-last-active").textContent = `Last active: ${user.lastActive}`
    document.getElementById("user-login-frequency").textContent = `Login frequency: ${user.loginFrequency}`

    // Set activity score with color
    const activityScoreEl = document.getElementById("user-activity-score")
    activityScoreEl.textContent = user.activityScore
    activityScoreEl.className = "font-bold"
    if (user.activityScore >= 80) {
      activityScoreEl.classList.add("text-green-500")
    } else if (user.activityScore >= 50) {
      activityScoreEl.classList.add("text-yellow-500")
    } else {
      activityScoreEl.classList.add("text-red-500")
    }

    // Set progress bars
    document.getElementById("user-activity-progress").style.width = `${user.activityScore}%`
    document.getElementById("user-license-usage").textContent = user.licenseUsage
    document.getElementById("user-license-progress").style.width = user.licenseUsage

    // Set apps
    const appsContainer = document.getElementById("user-apps")
    appsContainer.innerHTML = ""
    user.apps.forEach((app) => {
      const appBadge = document.createElement("span")
      appBadge.className =
        "inline-flex items-center rounded-full border dark:border-gray-700 px-2.5 py-0.5 text-xs font-semibold"
      appBadge.textContent = app
      appsContainer.appendChild(appBadge)
    })

    // Set summary info
    document.getElementById("summary-user-name").textContent = user.name
    document.getElementById("summary-login-frequency").textContent = user.loginFrequency
    document.getElementById("summary-last-active").textContent = user.lastActive

    const summaryActivityScoreEl = document.getElementById("summary-activity-score")
    summaryActivityScoreEl.textContent = user.activityScore
    summaryActivityScoreEl.className = "text-2xl font-bold"
    if (user.activityScore >= 80) {
      summaryActivityScoreEl.classList.add("text-green-500")
    } else if (user.activityScore >= 50) {
      summaryActivityScoreEl.classList.add("text-yellow-500")
    } else {
      summaryActivityScoreEl.classList.add("text-red-500")
    }

    document.getElementById("summary-license-usage").textContent = user.licenseUsage

    // Show/hide license warning
    const licenseWarning = document.getElementById("license-warning")
    if (Number.parseInt(user.licenseUsage) < 30) {
      licenseWarning.classList.remove("hidden")
    } else {
      licenseWarning.classList.add("hidden")
    }

    // Populate app usage
    const appUsageContainer = document.getElementById("app-usage")
    appUsageContainer.innerHTML = ""
    user.apps.forEach((app) => {
      const usagePercent = Math.floor(Math.random() * 100) + 1
      const hoursPerWeek = Math.floor(Math.random() * 20) + 1

      const appUsage = document.createElement("div")
      appUsage.className = "space-y-1"
      appUsage.innerHTML = `
        <div class="flex items-center justify-between">
          <span class="text-sm font-medium">${app}</span>
          <span class="text-sm text-gray-500 dark:text-gray-400">${hoursPerWeek}h per week</span>
        </div>
        <div class="h-2 w-full bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
          <div class="h-full bg-blue-500" style="width: ${usagePercent}%"></div>
        </div>
      `

      appUsageContainer.appendChild(appUsage)
    })

    // Populate login history
    const loginHistoryContainer = document.getElementById("login-history")
    loginHistoryContainer.innerHTML = ""
    loginData.forEach((login) => {
      const loginItem = document.createElement("div")
      loginItem.className =
        "flex items-center justify-between rounded-lg border dark:border-gray-700 p-3 hover:bg-gray-50 dark:hover:bg-gray-700"
      loginItem.innerHTML = `
        <div class="flex items-center gap-3">
          <div class="flex h-9 w-9 items-center justify-center rounded-full bg-blue-100 dark:bg-blue-900">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-blue-600 dark:text-blue-300"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" x2="3" y1="12" y2="12"/></svg>
          </div>
          <div>
            <p class="font-medium">${login.date}</p>
            <p class="text-sm text-gray-500 dark:text-gray-400">${login.time} • ${login.source}</p>
          </div>
        </div>
        <div class="text-sm font-medium">Session: ${login.duration}</div>
      `

      loginHistoryContainer.appendChild(loginItem)
    })

    // Initialize user history chart
    if (!window.userHistoryChart) {
      window.userHistoryChart = new Chart(document.getElementById("user-history-chart"), {
        type: "line",
        data: {
          labels: historicalData.map((item) => item.month),
          datasets: [
            {
              label: "Activity Score",
              data: historicalData.map((item) => item.score),
              borderColor: "#0ea5e9",
              backgroundColor: "rgba(14, 165, 233, 0.1)",
              tension: 0.3,
              fill: true,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            y: {
              beginAtZero: true,
              max: 100,
              grid: {
                color: "rgba(0, 0, 0, 0.05)",
              },
            },
            x: {
              grid: {
                display: false,
              },
            },
          },
          plugins: {
            legend: {
              display: false,
            },
            tooltip: {
              mode: "index",
              intersect: false,
            },
          },
        },
      })
    } else {
      window.userHistoryChart.data.datasets[0].data = historicalData.map((item) => item.score)
      window.userHistoryChart.update()
    }

    // Show modal
    modal.classList.remove("hidden")
    modal.classList.add("flex")
  }

  // Close user modal
  function closeUserModal() {
    const modal = document.getElementById("user-detail-modal")
    modal.classList.add("hidden")
    modal.classList.remove("flex")
  }

  // Toggle mobile filter modal
  function toggleMobileFilterModal() {
    const modal = document.getElementById("mobile-filter-modal")
    if (modal.classList.contains("hidden")) {
      modal.classList.remove("hidden")
      modal.classList.add("flex")
    } else {
      modal.classList.add("hidden")
      modal.classList.remove("flex")
    }
  }

  // Tab switching in user modal
  function setupTabs() {
    const tabButtons = document.querySelectorAll("[data-tab]")
    const tabContents = document.querySelectorAll(".tab-content")

    tabButtons.forEach((button) => {
      button.addEventListener("click", () => {
        // Remove active class from all buttons
        tabButtons.forEach((btn) => {
          btn.classList.remove("border-b-2", "border-primary-600", "text-primary-600")
          btn.classList.add("text-gray-500", "dark:text-gray-400", "hover:text-gray-700", "dark:hover:text-gray-300")
        })

        // Add active class to clicked button
        button.classList.add("border-b-2", "border-primary-600", "text-primary-600")
        button.classList.remove(
          "text-gray-500",
          "dark:text-gray-400",
          "hover:text-gray-700",
          "dark:hover:text-gray-300",
        )

        // Hide all tab contents
        tabContents.forEach((content) => {
          content.classList.add("hidden")
        })

        // Show selected tab content
        const tabId = button.getAttribute("data-tab")
        document.getElementById(`tab-${tabId}`).classList.remove("hidden")
      })
    })
  }

  // Sort users when clicking on table header
  document.getElementById("sort-activity").addEventListener("click", function () {
    if (sortField === "activityScore") {
      sortDirection = sortDirection === "asc" ? "desc" : "asc"
    } else {
      sortField = "activityScore"
      sortDirection = "desc"
    }

    // Update sort icon
    const sortIcon = this.querySelector("svg")
    if (sortDirection === "asc") {
      sortIcon.innerHTML = '<path d="m6 15 6-6 6 6"/>'
    } else {
      sortIcon.innerHTML = '<path d="m6 9 6 6 6-6"/>'
    }

    populateUserTable()
  })

  // Search users
  document.getElementById("search-users").addEventListener("input", function () {
    const searchTerm = this.value.toLowerCase()
    const rows = document.querySelectorAll("#user-table-body tr")

    rows.forEach((row) => {
      const userName = row.querySelector("td:first-child .font-medium").textContent.toLowerCase()
      const userEmail = row.querySelector("td:first-child .text-xs").textContent.toLowerCase()
      const userDepartment = row.querySelector("td:nth-child(2)").textContent.toLowerCase()

      if (userName.includes(searchTerm) || userEmail.includes(searchTerm) || userDepartment.includes(searchTerm)) {
        row.style.display = ""
      } else {
        row.style.display = "none"
      }
    })
  })

  // Event listeners
  document.getElementById("mobile-filter-button").addEventListener("click", toggleMobileFilterModal)
  document.getElementById("close-filter-modal").addEventListener("click", toggleMobileFilterModal)
  document.getElementById("close-user-modal").addEventListener("click", closeUserModal)
  document.getElementById("close-user-modal-btn").addEventListener("click", closeUserModal)

  // Initialize
  populateUserTable()
  populateInactivityAlerts()
  setupTabs()
})
