document.addEventListener('DOMContentLoaded', function() {
  // Sidebar toggle
  const sidebarToggle = document.getElementById('sidebar-toggle');
  const sidebar = document.getElementById('sidebar');
  const pageTitle = document.getElementById('page-title');
  
  sidebarToggle.addEventListener('click', function() {
    if (sidebar.classList.contains('-translate-x-full')) {
      sidebar.classList.remove('-translate-x-full');
      sidebar.classList.add('translate-x-0');
      
      // Change icon
      const icon = sidebarToggle.querySelector('i');
      icon.classList.remove('fa-bars');
      icon.classList.add('fa-times');
    } else {
      sidebar.classList.remove('translate-x-0');
      sidebar.classList.add('-translate-x-full');
      
      // Change icon
      const icon = sidebarToggle.querySelector('i');
      icon.classList.remove('fa-times');
      icon.classList.add('fa-bars');
    }
  });
  
  // Navigation
  const navItems = document.querySelectorAll('.nav-item');
  const pages = document.querySelectorAll('.page');
  
  navItems.forEach(item => {
    item.addEventListener('click', function() {
      const pageId = this.getAttribute('data-page');
      
      // Update active nav item
      navItems.forEach(nav => {
        nav.classList.remove('bg-primary', 'text-primary-foreground');
        nav.classList.add('hover:bg-gray-100');
      });
      this.classList.add('bg-primary', 'text-primary-foreground');
      this.classList.remove('hover:bg-gray-100');
      
      // Show selected page
      pages.forEach(page => page.classList.remove('active'));
      document.getElementById(`${pageId}-page`).classList.add('active');
      
      // Update page title
      pageTitle.textContent = this.textContent.trim();
      
      // Close sidebar on mobile
      if (window.innerWidth < 768) {
        sidebar.classList.remove('translate-x-0');
        sidebar.classList.add('-translate-x-full');
        
        const icon = sidebarToggle.querySelector('i');
        icon.classList.remove('fa-times');
        icon.classList.add('fa-bars');
      }
    });
  });
  
  // Dropdown menus
  const dropdownToggles = document.querySelectorAll('.dropdown-toggle');
  
  dropdownToggles.forEach(toggle => {
    toggle.addEventListener('click', function(e) {
      e.stopPropagation();
      
      const dropdown = this.closest('.dropdown');
      
      // Close all other dropdowns
      document.querySelectorAll('.dropdown').forEach(d => {
        if (d !== dropdown) {
          d.classList.remove('active');
        }
      });
      
      // Toggle current dropdown
      dropdown.classList.toggle('active');
    });
  });
  
  // Close dropdowns when clicking outside
  document.addEventListener('click', function() {
    document.querySelectorAll('.dropdown').forEach(dropdown => {
      dropdown.classList.remove('active');
    });
  });
  
  // Prevent dropdown menu clicks from closing the dropdown
  document.querySelectorAll('.dropdown-menu').forEach(menu => {
    menu.addEventListener('click', function(e) {
      e.stopPropagation();
    });
  });
  
  // Handle window resize
  window.addEventListener('resize', function() {
    if (window.innerWidth >= 768) {
      sidebar.classList.remove('translate-x-0', '-translate-x-full');
      
      const icon = sidebarToggle.querySelector('i');
      icon.classList.remove('fa-times');
      icon.classList.add('fa-bars');
    } else {
      sidebar.classList.add('-translate-x-full');
    }
  });
});